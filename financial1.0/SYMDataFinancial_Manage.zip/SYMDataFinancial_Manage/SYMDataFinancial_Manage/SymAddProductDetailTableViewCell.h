//
//  SymAddProductDetailTableViewCell.h
//  SYMDataFinancial_Manage
//
//  Created by cuiyong on 15/11/26.
//  Copyright © 2015年 symdata. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SymAddProductDetailTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *RiskLevel;
@property (weak, nonatomic) IBOutlet UILabel *MoneyLabel;
@property (weak, nonatomic) IBOutlet UILabel *MultipleLabel;
@property (weak, nonatomic) IBOutlet UILabel *MonthLabel;
@property (weak, nonatomic) IBOutlet UILabel *DealWithLabel;
@property (weak, nonatomic) IBOutlet UILabel *PoundageLabel;
@property (weak, nonatomic) IBOutlet UILabel *StartTimeLabel;
@property (weak, nonatomic) IBOutlet UILabel *EndTimeLabel;
@property (weak, nonatomic) IBOutlet UILabel *UnitLabel;

@end
