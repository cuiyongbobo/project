//
//  SymAddProductDetailMoreTableViewCell.h
//  SYMDataFinancial_Manage
//
//  Created by cuiyong on 15/11/26.
//  Copyright © 2015年 symdata. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SymAddProductDetailMoreTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIWebView *DescribeWebView;
@end
