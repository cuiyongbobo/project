//
//  SYMconsultingViewController.h
//  SYMDataFinancial_Manage
//
//  Created by cuiyong on 15/12/22.
//  Copyright © 2015年 symdata. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainViewController.h"

@interface SYMconsultingViewController : MainViewController
@property (weak, nonatomic) IBOutlet UITableView *BDtableview;

@end
