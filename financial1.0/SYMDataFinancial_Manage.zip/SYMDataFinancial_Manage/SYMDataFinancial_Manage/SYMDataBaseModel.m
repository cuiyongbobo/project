//
//  SYMDataBaseModel.m
//  SYMDataFinancial_Manage
//
//  Created by cuiyong on 15/11/27.
//  Copyright © 2015年 symdata. All rights reserved.
//

#import "SYMDataBaseModel.h"

@implementation SYMDataBaseModel

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}
@end


@implementation FinancialSupermarket

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}
@end

@implementation ProductList

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}
@end

@implementation ProductDetails

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}
@end

@implementation BankChoose

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}
@end

@implementation OpenAccount

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}
@end

@implementation CustomerInformation

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}
@end

@implementation MyAsset

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}
@end

@implementation TransactionRecords

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}
@end

@implementation RegularBasisList

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}
@end

@implementation ListCash

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}
@end

@implementation Withdrawal

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}
@end

@implementation Province

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}
@end

@implementation City

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}
@end

@implementation WithdrawalResults

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}
@end

@implementation PersonalInformation

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}
@end

@implementation SelfBankCard

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}
@end

@implementation Buyproduct

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}
@end

@implementation UserInformation

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}
@end




