//
//  RecommendedTableViewCell.h
//  SYMDataFinancial_Manage
//
//  Created by cuiyong on 15/11/29.
//  Copyright © 2015年 symdata. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RecommendedTableViewCell : UITableViewCell

@end
