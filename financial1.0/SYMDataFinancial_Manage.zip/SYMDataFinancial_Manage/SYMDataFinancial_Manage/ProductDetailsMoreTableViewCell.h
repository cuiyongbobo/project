//
//  ProductDetailsMoreTableViewCell.h
//  SYMDataFinancial_Manage
//
//  Created by cuiyong on 15/11/17.
//  Copyright © 2015年 symdata. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProductDetailsMoreTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *ExpectedEarnings;
@property (weak, nonatomic) IBOutlet UILabel *WanBenefit;
@property (weak, nonatomic) IBOutlet UILabel *BenefitMoney;
@property (weak, nonatomic) IBOutlet UILabel *Unit;

@end
