//
//  PwdView.h
//  BitMainWallet_Hot
//
//  Created by cuiyong on 15/6/23.
//  Copyright (c) 2015年 xunianqiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PwdView : UIView
@property (nonatomic,assign) NSUInteger pwdCount;
- (void)setCount:(NSInteger)count;
@end
