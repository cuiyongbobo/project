//
//  MyAssetSectionSecondTableViewCell.h
//  SYMDataFinancial_Manage
//
//  Created by cuiyong on 15/11/19.
//  Copyright © 2015年 symdata. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyAssetSectionSecondTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *AssetIcon;
@property (weak, nonatomic) IBOutlet UILabel *AssetName;
@property (weak, nonatomic) IBOutlet UIImageView *AssetIconClick;
@property (weak, nonatomic) IBOutlet UILabel *RegularAmount;
@end
