//
//  MyAssetSectionOneTableViewCell.h
//  SYMDataFinancial_Manage
//
//  Created by cuiyong on 15/11/19.
//  Copyright © 2015年 symdata. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyAssetSectionOneTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *Yesterdayearn;
@property (weak, nonatomic) IBOutlet UILabel *CumulativeEarn;

@end
