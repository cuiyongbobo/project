//
//  SYMMyAssetTakeOutResultsTableViewCell.m
//  SYMDataFinancial_Manage
//
//  Created by cuiyong on 15/11/20.
//  Copyright © 2015年 symdata. All rights reserved.
//

#import "SYMMyAssetTakeOutResultsTableViewCell.h"

@implementation SYMMyAssetTakeOutResultsTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
