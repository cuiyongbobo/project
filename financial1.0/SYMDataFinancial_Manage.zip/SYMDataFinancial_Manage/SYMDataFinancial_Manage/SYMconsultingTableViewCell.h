//
//  SYMconsultingTableViewCell.h
//  SYMDataFinancial_Manage
//
//  Created by cuiyong on 15/12/22.
//  Copyright © 2015年 symdata. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SYMconsultingTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *contentPicter;
@property (weak, nonatomic) IBOutlet UILabel *showDateLabel;

@end
