//
//  SYMPersonalMoreCell.h
//  SYMDataFinancial_Manage
//
//  Created by cuiyong on 15/11/10.
//  Copyright © 2015年 symdata. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SYMPersonalMoreCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *InformationLabel;
@property (weak, nonatomic) IBOutlet UIImageView *ArrowImageView;
@property (weak, nonatomic) IBOutlet UILabel *PhoneNumber;

@end
