//
//  SYMFinancialRegularTableViewCell.h
//  SYMDataFinancial_Manage
//
//  Created by cuiyong on 15/11/23.
//  Copyright © 2015年 symdata. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SYMFinancialRegularTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIButton *Reflectbutton;
@property (weak, nonatomic) IBOutlet UILabel *ReflectBalance;

@end
