//
//  TiedCardMoreTableViewCell.h
//  SYMDataFinancial_Manage
//
//  Created by cuiyong on 15/11/24.
//  Copyright © 2015年 symdata. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TiedCardMoreTableViewCell : UITableViewCell

@end
