//
//  helloViewController.h
//  zplayXGZSDK
//
//  Created by ZPLAY005 on 14-1-23.
//  Copyright (c) 2014年 ZPLAY005. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface helloViewController : UIViewController
@property (retain, nonatomic) IBOutlet UIButton *loginView;
- (IBAction)pay:(id)sender;
- (IBAction)pay2:(id)sender;
- (IBAction)YHcontenterV:(id)sender;


@end
