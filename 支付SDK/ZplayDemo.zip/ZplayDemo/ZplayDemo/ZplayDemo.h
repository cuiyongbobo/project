//
//  ZplayDemo.h
//  ZplayDemo
//
//  Created by MyDelegate on 14/11/10.
//  Copyright (c) 2014年 LB. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface ZplayDemo : NSObject

+(ZplayDemo *)shareInstance;
-(void)login:(UIViewController *)vctrl;

-(void)userCente:(UIViewController *)viewCtrl;

-(void)payViewGameText:(NSString *)gT commodityText:(NSString *)cT priceText:(NSString *)pT cpDefineInfo:(NSString *)cpIfo ViewController:(UIViewController *)viewCtrl;

-(void)payView2GameText:(NSString *)gT cpDefineInfo:(NSString *)cpIfo ViewController:(UIViewController *)viewCtrl;


@end
