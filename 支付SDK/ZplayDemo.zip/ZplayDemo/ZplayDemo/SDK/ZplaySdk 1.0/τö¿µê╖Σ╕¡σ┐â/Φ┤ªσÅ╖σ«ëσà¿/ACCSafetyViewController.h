//
//  ACCSafetyViewController.h
//  ZplayAppStoreSDK
//
//  Created by ZPLAY005 on 14-3-20.
//  Copyright (c) 2014年 vbdsgfht. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ACCSafetyViewController : UIViewController

@end
