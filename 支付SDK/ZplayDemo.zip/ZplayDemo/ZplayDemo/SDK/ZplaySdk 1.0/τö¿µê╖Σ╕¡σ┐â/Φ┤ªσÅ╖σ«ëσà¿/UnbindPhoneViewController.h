//
//  UnbindPhoneViewController.h
//  ZplayAppStoreSDK
//
//  Created by ZPLAY005 on 14-3-20.
//  Copyright (c) 2014年 vbdsgfht. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UnbindPhoneViewController : UIViewController
@property(nonatomic,retain)NSString *strStryl;
@property(nonatomic,retain)NSString *userStr;
@end
//13716147410 133ad6fb5d1cd16f84858650a800f2e8