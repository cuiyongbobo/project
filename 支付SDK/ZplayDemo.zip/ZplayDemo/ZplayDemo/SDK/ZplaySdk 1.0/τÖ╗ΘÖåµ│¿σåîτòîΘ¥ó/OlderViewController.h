//
//  OlderViewController.h
//  zplaySDk1.0
//
//  Created by ZPLAY005 on 14-3-14.
//  Copyright (c) 2014年 ZPLAY005. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OlderViewController : UIViewController
@property(nonatomic,retain)NSString *userstr;
@end
